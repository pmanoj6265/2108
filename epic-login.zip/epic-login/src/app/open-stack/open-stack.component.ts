import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-stack',
  templateUrl: './open-stack.component.html',
  styleUrls: ['./open-stack.component.css']
})
export class OpenStackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

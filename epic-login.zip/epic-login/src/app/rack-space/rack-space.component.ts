import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rack-space',
  templateUrl: './rack-space.component.html',
  styleUrls: ['./rack-space.component.css']
})
export class RackSpaceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
